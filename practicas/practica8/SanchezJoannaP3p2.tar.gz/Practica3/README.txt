Integrantes :

Lopez Perez Frida Fernanda
- Número de cuenta: 315110520.

Rubí Rojas Tania Michelle
- Número de cuenta: 315121719

Sánchez Rangel Joanna Lizeth.
- Número de cuenta: 315060982.